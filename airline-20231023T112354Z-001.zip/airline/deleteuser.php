<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width;initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<title>DELETE FLIGHT</title>
</head>
<body style="background-image:linear-gradient(90deg,lightcyan,skyblue)"> 
	<div class="container my-5" style="border:2px solid brown;">
				<?php
				//STEP0 - INITILAZIE VARIABLE
				$pno=$_GET['pno'];
				//STEP1 - INITIALIZING THE DATABASE
				//I.P ADDRESS,USERNAME,PASSWORD,DBNAME
				$connection=mysqli_connect("localhost","root","","air");
				//STEP-2 WRITE SQL QUERY
				$query="DELETE FROM passenger WHERE PId='$pno'";
				//STEP- 3 EXECUTE THE QUERY
				$qryobj=mysqli_query($connection,$query);
				//STEP - 4 FETCH ROWS //STEP 5 - DISPLAY THE CONTENT
				//STEP -5 ACKNOWLEDGE
				if(isset($qryobj))
				{
					echo "DELETED";
					echo "<a href='user.php'>CLICK HERE TO GO BACK</a>";
				}
				else
				{
					echo "ERROR";
				}
				?>
	</div>
</body>
</html>