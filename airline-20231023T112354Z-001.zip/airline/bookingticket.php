<?php


$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="air";
$db_port=3306;

//create Connection
$conn=new mysqli($db_host,$db_user,$db_password,$db_name,$db_port);

//checking connection
if($conn->connect_error)
{
	die("connection_failed");
}
else
{
	echo "connect";
}




    echo $fno=$_POST['fno'];
    echo $pid=$_POST['pid'];
 
$conn=mysqli_connect("localhost","root","","air");

//STEP-3 WRITE SQL QUERY
$query="INSERT INTO booking(PId,FlightNo,PType) values('$pid','$fno','c')";

//STEP- 4 EXECUTE THE QUERY
if($obj=mysqli_query($conn,$query))
{
    echo "Booked SUCCESSFULLY";
    echo "<script> location.href='/airline/bookticket.html'; alert('Booked Successfully') </script>";
}
else{
      echo "Booking Failed";
      echo "<script> location.href='/airline/bookticket.html'; alert('Booking failed! Check your flight number is valid or not!') </script>";
}



?>

