<html>

<head>
<title>Users</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-
awesome.min.css">
<link rel="stylesheet" type="text/css"
href="http://fonts.googleapis.com/css?family=Poppins">

<link rel="stylesheet" href="mycss.css">

</head>

<body>

<nav class="navbar navbar-inverse" style="border-radius:0px !important;

margin-bottom: 0">
<div class="container-fluid">
<div class="navbar-header">

<button type="button" class="navbar-toggle" data-toggle="collapse" data-
target="#myNavbar">
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.html">AirLine</a>
<ul class="nav navbar-nav navbar-right">
								<li><a href="index.html" >Logout</a></li>
							</ul>
<ul class="nav navbar-nav">
<li><a href="aboutus.html">About Us</a></li>
</ul>
</div>

</nav>

<div class="container" data-spy="affix" style="margin: 0;bottom: 0;float: left;top:5rem;width:
20%;height:100%; background-color: #222222">

<ul class="nav nav-pills nav-stacked" style="width:100%;">
<li>
<a ></a>


</li>

<li>
<a >Flight Schedule</a>
<ul style="padding: 0 0 0 0">
<div class="list-group">

<a href="newairline.html" class="list-group-item">Add new

Airline</a>

<a href="manageairline.php" class="list-group-item ">Manage

Airline</a>

</div>

</ul>
</li>

</div>

<div class="container-fluid" style="float: right; width: 80%">
<h2>Users</h2>
<hr>

</div>
<div class="container" style="margin-left: 0; float: right; width:80%; margin-top:

10px; padding: 0 5rem 0 5rem">
<div>

</div>
<br>
<table class="table table-striped table-hover">
<thead>
<tr>
<th>ID</th>
<th>FirstName</th>
<th>LastName</th>
<th>Gender</th>
<th>Phone</th>
<th>Email</th>
</tr>
</thead>
<tbody>
				<?php
				//STEP1 - INITIALIZING THE DATABASE
				//I.P ADDRESS,USERNAME,PASSWORD,DBNAME
				$connection=mysqli_connect("localhost","root","","air");
				//STEP-2 WRITE SQL QUERY
				$query="SELECT * FROM passenger order by PId";
				//STEP- 3 EXECUTE THE QUERY
				$qryobj=mysqli_query($connection,$query);
				//STEP - 4 FETCH ROWS //STEP 5 - DISPLAY THE CONTENT
				while($row=mysqli_fetch_assoc($qryobj))
				{
					echo '<tr>';
					echo '<td>'.$row['PId'].'</td>';
					echo '<td>'.$row['FName'].'</td>';
					echo '<td>'.$row['LName'].'</td>';
					echo '<td>'.$row['Sex'].'</td>';
					echo '<td>'.$row['PhoneNo'].'</td>';
					echo '<td>'.$row['Email'].'</td>';
					//echo '<td><a href="deletestudent.php?sid='.$row['STUDENTID'].'">DELETE STUDENT</a></td>';
					echo '<td><a href="deleteuser.php?pno='.$row['PId'].'"><button class="btn btn-primary">DELETE PASSENGER</button></a></td>';
					//deletestudent.php?sid=25
					echo '</tr>';
				}
				?>
</tbody>
</div>
</div>

<div class="modal small fade" id="myModal" tabindex="-1"

role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-

dismiss="modal" aria-hidden="true">×</button>

<h3 id="myModalLabel">Delete

Confirmation</h3>

</div>
<div class="modal-body">
<p class="error-text"><i class="fa fa-warning
modal-icon"></i> Are you sure you want to delete the user?<br>This cannot be undone.</p>

</div>
<div class="modal-footer">

<button class="btn btn-default" data-

dismiss="modal" aria-hidden="true">Cancel</button>

<button class="btn btn-danger" data-

dismiss="modal">Delete</button>

</div>
</div>
</div>
</div>

</body>
</html>