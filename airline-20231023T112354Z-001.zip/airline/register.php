<?php
//if(isset($_POST['sbtbtn']))
//{
    echo $fname=$_POST['fname'];
    echo $lname=$_POST['lname'];
    echo $gender=$_POST['gender'];
    echo $email=$_POST['email'];
    echo $password=$_POST['password'];
    echo $phone=$_POST['phone'];


$conn=mysqli_connect("localhost","root","","air");

//STEP-3 WRITE SQL QUERY
$query="INSERT INTO passenger(FName,LName,Email,Password,Sex,PhoneNo) values('$fname','$lname','$email','$password','$gender','$phone')";

//STEP- 4 EXECUTE THE QUERY
if($obj=mysqli_query($conn,$query))
{
    echo "REGISTERED SUCCESSFULLY";
    echo "<script> location.href='/airline/userlogin.html'; alert('Successfully registered') </script>";
}
else{
      echo "Registration Failed";
      echo "<script> location.href='/airline/register.html'; alert('Registration Failed') </script>";
}
//}


?>

