<?php

    echo $email=$_POST['email'];
    echo $password=$_POST['password'];

$conn=mysqli_connect("localhost","root","","air");




$query = "SELECT PId FROM passenger WHERE passenger.Email='$email' and passenger.Password='$password'";

$obj=mysqli_query($conn,$query);

if($row=mysqli_fetch_assoc($obj))
{
    $id =  $row['PId'];
    echo "Login Successfull";
    echo "<script> location.href='/airline/bookticket.html'; alert('Successfully Logged In'); localStorage.setItem('id', $id); </script>";
    
}
else{
      echo "Login Failed";
      echo "<script> location.href='/airline/userlogin.html'; alert('Login failed') </script>";
}

?>

