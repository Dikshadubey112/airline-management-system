<html>

<head>
<title>Manage Airline</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-
awesome.min.css">
<link rel="stylesheet" type="text/css"
href="http://fonts.googleapis.com/css?family=Poppins">

<link rel="stylesheet" href="mycss.css">
<script type="text/javascript" src="myjs.js"></script>
</head>

<style type="text/css">
.affix{
top:5rem;
}

body{
position: relative;
};

</style>
<body data-spy="scroll" data-target="#myscroll">

<nav class="navbar navbar-inverse" data-spy="affix" style="border-
radius:0px !important; margin:0;border: 0 ; width: 100%;top:0;z-index: 9999 !important">

<div class="navbar-header">
<a class="navbar-brand" href="index.html">BOOK AIRLINE</a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
<li><a href="aboutus.html">About Us</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
								<li><a href="index.html" >Logout</a></li>
							</ul>
</div>
</nav>
<!--container strat-->
<div class="container" data-spy="affix" style="margin: 0;bottom: 0;float: left;top:5rem;width: 20%;height:100%; background-color: #222222">
<ul class="nav nav-pills nav-stacked" style="border-radius: 0">
<li>
<a ></a>
<ul style="padding: 0 0 0 0">
<div class="list-group">
<li><a href="user.php" class="list-group-item">Users</a></li>
</div>
</ul>

</li>
<li>
<a >Airline Schedule</a>
<ul id="sub2" style="padding: 0 0 0 0">
<div class="list-group" >

<a href="newairline.html" class="list-group-item">Add new

Airline</a>



</div>
</ul>
</li>
</div>

<!--scrooll container start-->
<div id="#myscroll" class="container" style="margin-left: 0;margin-top: 5rem; float: right; width:80%; padding: 0 5rem 0 5rem">
<h2>Manage Airline</h2>
<hr>
<div>
</div>
<br>
<table class="table table-striped table-hover">
<thead>
<tr>
<th>airlineNo</th>
<th>From</th>
<th>To</th>
<th>Date</th>
<th>Time</th>
<!-- <th>Capacity</th>-->
</tr>
</thead>


<tbody>
				<?php
				//STEP1 - INITIALIZING THE DATABASE
				//I.P ADDRESS,USERNAME,PASSWORD,DBNAME
				$connection=mysqli_connect("localhost","root","","air");
				//STEP-2 WRITE SQL QUERY
				$query="SELECT * FROM flight order by FlightNo";
				//STEP- 3 EXECUTE THE QUERY
				$qryobj=mysqli_query($connection,$query);
				//STEP - 4 FETCH ROWS //STEP 5 - DISPLAY THE CONTENT
				while($row=mysqli_fetch_assoc($qryobj))
				{
					echo '<tr>';
					echo '<td>'.$row['FlightNo'].'</td>';
					echo '<td>'.$row['From'].'</td>';
					echo '<td>'.$row['To'].'</td>';
					echo '<td>'.$row['Date'].'</td>';
					echo '<td>'.$row['Time'].'</td>';
					//echo '<td><a href="deletestudent.php?sid='.$row['STUDENTID'].'">DELETE STUDENT</a></td>';
					echo '<td><a href="deleteflight.php?fno='.$row['FlightNo'].'"><button class="btn btn-primary">DELETE FLIGHT</button></a></td>';
					//deletestudent.php?sid=25
					echo '</tr>';
				}
				?>
</tbody>

</table>
</div>


</body>

</html>