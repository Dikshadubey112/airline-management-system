<?php

$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="air";
$db_port=3306;

//create Connection
$conn=new mysqli($db_host,$db_user,$db_password,$db_name,$db_port);

//checking connection
if($conn->connect_error)
{
	die("connection_failed");
}
else
{
	echo "connect";
}



    echo $email=$_POST['email'];
    echo $password=$_POST['password'];

$conn=mysqli_connect("localhost","root","","air");
//cp-3
//write a query
//insert into table_name(col1,col2) values('','');
$query="INSERT into airline(email,password) values('$email','$password')";



$query = "SELECT Email FROM admin WHERE admin.Email='$email' and admin.Password='$password'";

$obj=mysqli_query($conn,$query);

if($row=mysqli_fetch_assoc($obj))
{
    echo "Login Successfull";
    echo "<script> location.href='/airline/newairline.html'; alert('Successfully Loged In') </script>";
}
else{
      echo "Login Failed";
      echo "<script> location.href='/airline/adminlogin.html'; alert('Login failed') </script>";
}

?>

