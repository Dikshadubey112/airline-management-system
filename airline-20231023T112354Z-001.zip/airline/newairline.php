<?php
//if(isset($_POST['sbtbtn']))
//{
    echo $num=$_POST['num'];
    echo $origin=$_POST['origin'];
    echo $dest=$_POST['dest'];
    echo $date=$_POST['date1'];
    echo $time=$_POST['time'];
    echo $price=$_POST['price'];


$conn=mysqli_connect("localhost","root","","air");

//STEP-3 WRITE SQL QUERY
$query="INSERT INTO flight values('$num','$origin','$dest','$time','$price','$date')";

//STEP- 4 EXECUTE THE QUERY
if($obj=mysqli_query($conn,$query))
{
    echo "REGISTERED SUCCESSFULLY";
    echo "<script> location.href='/airline/newairline.html'; alert('Successfully Added') </script>";
}
else{
      echo "Registration Failed";
      echo "<script> location.href='/airline/newairline.html'; alert('NOT ADDED! Something went wrong') </script>";
}
//}
?>

