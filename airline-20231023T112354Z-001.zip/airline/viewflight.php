<html>
	<head>
		<title>Book Ticket</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
				<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Poppins">

		<link rel="stylesheet" href="mycss.css">
	</head>
	<style type="text/css">
				label{
			color: darkred;
		}
	</style>
	<body>
				<nav class="navbar navbar-inverse" style="border-radius:0px !important; margin:0;border: 0">
					<div class="container-fluid">
						<div class="navbar-header">
						  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>                       
						  </button>
						  <a class="navbar-brand" href="index.html">AirLine</a>
						</div>
						<div class="collapse navbar-collapse" id="myNavbar">
							<ul class="nav navbar-nav">
                                <li ><a href="bookticket.html">Book Ticket</a></li>
                                <li class="active" ><a href="viewflight.php">Check Flights</a></li>
								<li ><a href="aboutus.html">About Us</a></li>
							</ul>
							<ul class="nav navbar-nav navbar-right">
								<li><a href="index.html" >Logout</a></li>
							</ul>
						</div>	
					</div>
				</nav>
				
				

				<div class="background-wrapper" style="background-image: url(https://wallpapercave.com/wp/wp2100655.jpg);">
				
				<!--header-->

				<div class="container-fluid">
					<header>
						<h2 style="color:darkred;">Check Flights</h2>
						<hr>
					</header>


					<!--panel-->
					<div class="col-sm-8 col-sm-offset-2">
                    <table class="table table-striped table-hover">
<thead>
<tr>
<th>airlineNo</th>
<th>From</th>
<th>To</th>
<th>Date</th>
<th>Time</th>
<th>Price</th>
<!-- <th>Capacity</th>-->
</tr>
</thead>


<tbody>
				<?php
				//STEP1 - INITIALIZING THE DATABASE
				//I.P ADDRESS,USERNAME,PASSWORD,DBNAME
				$connection=mysqli_connect("localhost","root","","air");
				//STEP-2 WRITE SQL QUERY
				$query="SELECT * FROM flight order by FlightNo";
				//STEP- 3 EXECUTE THE QUERY
				$qryobj=mysqli_query($connection,$query);
				//STEP - 4 FETCH ROWS //STEP 5 - DISPLAY THE CONTENT
				while($row=mysqli_fetch_assoc($qryobj))
				{
					echo '<tr>';
					echo '<td>'.$row['FlightNo'].'</td>';
					echo '<td>'.$row['From'].'</td>';
					echo '<td>'.$row['To'].'</td>';
					echo '<td>'.$row['Date'].'</td>';
                    echo '<td>'.$row['Time'].'</td>';
                    echo '<td>'.$row['Price'].'</td>';
					echo '</tr>';
				}
				?>
</tbody>

</table>
					</div>
				</div>
			</div>


			<!-- Footer -->
			<footer id="footer">
				
				<div class="copyright">
					&copy; AirLine.
				</div>
			</footer>

	</body>
</html>